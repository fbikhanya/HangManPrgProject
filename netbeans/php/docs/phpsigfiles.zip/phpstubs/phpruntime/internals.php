<?php

namespace {

	class stdClass {
	}

}
