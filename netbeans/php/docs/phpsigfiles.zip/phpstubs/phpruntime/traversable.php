<?php

namespace {

	/**
	 * <p>Interface to detect if a class is traversable using foreach.</p>
	 * <p>Abstract base interface that cannot be implemented alone. Instead, it must be implemented by either <code>IteratorAggregate</code> or <code>Iterator</code>.</p>
	 * @link https://php.net/manual/en/class.traversable.php
	 * @since PHP 5, PHP 7, PHP 8
	 */
	interface Traversable {
	}

}
